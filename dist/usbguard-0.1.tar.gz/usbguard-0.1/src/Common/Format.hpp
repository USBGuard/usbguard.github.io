#pragma once
#define FMT_HEADER_ONLY
#include "ThirdParty/cppformat/format.h"
