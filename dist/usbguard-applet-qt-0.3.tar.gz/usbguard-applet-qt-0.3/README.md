# usbguard-applet-qt
Qt applet for interacting with the [usbguard](https://github.com/dkopecek/usbguard) daemon.

## Screenshots

### Notifications
![USGuard Qt Applet notification](/screenshots/notification.png?raw=true "USBGuard Qt Applet notification")

### Device Dialog
![USGuard Qt Applet device dialog](/screenshots/devicedialog.png?raw=true "USBGuard Qt Applet device dialog")

### Message Log
![USGuard Qt Applet message log](/screenshots/messages.png?raw=true "USBGuard Qt Applet message log")
