namespace usbguard
{
  int usbguard_list_rules(int argc, char **argv);
} /* namespace usbguard */
