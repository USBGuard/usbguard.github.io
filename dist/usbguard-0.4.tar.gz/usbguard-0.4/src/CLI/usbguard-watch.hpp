namespace usbguard
{
  int usbguard_watch(int argc, char **argv);
} /* namespace usbguard */
