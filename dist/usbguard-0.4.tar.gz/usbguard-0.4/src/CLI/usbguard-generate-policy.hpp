namespace usbguard
{
  int usbguard_generate_policy(int argc, char **argv);
} /* namespace usbguard */
