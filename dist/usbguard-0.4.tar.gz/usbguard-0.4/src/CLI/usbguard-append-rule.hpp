namespace usbguard
{
  int usbguard_append_rule(int argc, char **argv);
} /* namespace usbguard */
