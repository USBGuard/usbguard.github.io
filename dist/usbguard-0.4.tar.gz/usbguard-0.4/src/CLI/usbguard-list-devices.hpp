namespace usbguard
{
  int usbguard_list_devices(int argc, char **argv);
} /* namespace usbguard */
