namespace usbguard
{
  int usbguard_block_device(int argc, char **argv);
} /* namespace usbguard */
