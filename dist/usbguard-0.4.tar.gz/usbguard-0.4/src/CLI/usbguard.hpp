#include <cstddef>
#include <cstdlib>
#include <getopt.h>

#include "LoggerPrivate.hpp"

namespace usbguard
{
  extern const char *usbguard_arg0;
} /* namespace usbguard */
