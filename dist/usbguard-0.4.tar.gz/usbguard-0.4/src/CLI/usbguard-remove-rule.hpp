namespace usbguard
{
  int usbguard_remove_rule(int argc, char **argv);
} /* namespace usbguard */
