namespace usbguard
{
  int usbguard_allow_device(int argc, char **argv);
} /* namespace usbguard */
