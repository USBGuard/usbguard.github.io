namespace usbguard
{
  int usbguard_reject_device(int argc, char **argv);
} /* namespace usbguard */
