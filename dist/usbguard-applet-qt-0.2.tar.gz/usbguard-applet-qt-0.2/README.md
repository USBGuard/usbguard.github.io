# usbguard-applet-qt
Qt applet for interacting with the [usbguard](https://github.com/dkopecek/usbguard) daemon.
