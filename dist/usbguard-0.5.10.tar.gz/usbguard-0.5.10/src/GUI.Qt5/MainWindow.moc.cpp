/****************************************************************************
** Meta object code from reading C++ file 'MainWindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "MainWindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[42];
    char stringdata0[628];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 16), // "uiDeviceInserted"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 2), // "id"
QT_MOC_LITERAL(4, 32, 33), // "std::map<std::string,std::str..."
QT_MOC_LITERAL(5, 66, 10), // "attributes"
QT_MOC_LITERAL(6, 77, 39), // "std::vector<usbguard::USBInte..."
QT_MOC_LITERAL(7, 117, 10), // "interfaces"
QT_MOC_LITERAL(8, 128, 10), // "rule_match"
QT_MOC_LITERAL(9, 139, 15), // "uiDevicePresent"
QT_MOC_LITERAL(10, 155, 22), // "usbguard::Rule::Target"
QT_MOC_LITERAL(11, 178, 6), // "target"
QT_MOC_LITERAL(12, 185, 15), // "uiDeviceRemoved"
QT_MOC_LITERAL(13, 201, 15), // "uiDeviceAllowed"
QT_MOC_LITERAL(14, 217, 15), // "uiDeviceBlocked"
QT_MOC_LITERAL(15, 233, 16), // "uiDeviceRejected"
QT_MOC_LITERAL(16, 250, 11), // "uiConnected"
QT_MOC_LITERAL(17, 262, 14), // "uiDisconnected"
QT_MOC_LITERAL(18, 277, 21), // "switchVisibilityState"
QT_MOC_LITERAL(19, 299, 33), // "QSystemTrayIcon::ActivationRe..."
QT_MOC_LITERAL(20, 333, 6), // "reason"
QT_MOC_LITERAL(21, 340, 9), // "flashStep"
QT_MOC_LITERAL(22, 350, 13), // "ipcTryConnect"
QT_MOC_LITERAL(23, 364, 16), // "showDeviceDialog"
QT_MOC_LITERAL(24, 381, 11), // "showMessage"
QT_MOC_LITERAL(25, 393, 7), // "message"
QT_MOC_LITERAL(26, 401, 5), // "alert"
QT_MOC_LITERAL(27, 407, 14), // "notifyInserted"
QT_MOC_LITERAL(28, 422, 12), // "rule_matched"
QT_MOC_LITERAL(29, 435, 13), // "notifyPresent"
QT_MOC_LITERAL(30, 449, 13), // "notifyRemoved"
QT_MOC_LITERAL(31, 463, 13), // "notifyAllowed"
QT_MOC_LITERAL(32, 477, 13), // "notifyBlocked"
QT_MOC_LITERAL(33, 491, 14), // "notifyRejected"
QT_MOC_LITERAL(34, 506, 18), // "notifyIPCConnected"
QT_MOC_LITERAL(35, 525, 21), // "notifyIPCDisconnected"
QT_MOC_LITERAL(36, 547, 11), // "allowDevice"
QT_MOC_LITERAL(37, 559, 6), // "append"
QT_MOC_LITERAL(38, 566, 11), // "blockDevice"
QT_MOC_LITERAL(39, 578, 12), // "rejectDevice"
QT_MOC_LITERAL(40, 591, 16), // "handleIPCConnect"
QT_MOC_LITERAL(41, 608, 19) // "handleIPCDisconnect"

    },
    "MainWindow\0uiDeviceInserted\0\0id\0"
    "std::map<std::string,std::string>\0"
    "attributes\0std::vector<usbguard::USBInterfaceType>\0"
    "interfaces\0rule_match\0uiDevicePresent\0"
    "usbguard::Rule::Target\0target\0"
    "uiDeviceRemoved\0uiDeviceAllowed\0"
    "uiDeviceBlocked\0uiDeviceRejected\0"
    "uiConnected\0uiDisconnected\0"
    "switchVisibilityState\0"
    "QSystemTrayIcon::ActivationReason\0"
    "reason\0flashStep\0ipcTryConnect\0"
    "showDeviceDialog\0showMessage\0message\0"
    "alert\0notifyInserted\0rule_matched\0"
    "notifyPresent\0notifyRemoved\0notifyAllowed\0"
    "notifyBlocked\0notifyRejected\0"
    "notifyIPCConnected\0notifyIPCDisconnected\0"
    "allowDevice\0append\0blockDevice\0"
    "rejectDevice\0handleIPCConnect\0"
    "handleIPCDisconnect"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      27,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    4,  149,    2, 0x06 /* Public */,
       9,    4,  158,    2, 0x06 /* Public */,
      12,    2,  167,    2, 0x06 /* Public */,
      13,    2,  172,    2, 0x06 /* Public */,
      14,    2,  177,    2, 0x06 /* Public */,
      15,    2,  182,    2, 0x06 /* Public */,
      16,    0,  187,    2, 0x06 /* Public */,
      17,    0,  188,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      18,    1,  189,    2, 0x09 /* Protected */,
      21,    0,  192,    2, 0x09 /* Protected */,
      22,    0,  193,    2, 0x09 /* Protected */,
      23,    4,  194,    2, 0x09 /* Protected */,
      24,    2,  203,    2, 0x09 /* Protected */,
      24,    1,  208,    2, 0x29 /* Protected | MethodCloned */,
      27,    4,  211,    2, 0x09 /* Protected */,
      29,    4,  220,    2, 0x09 /* Protected */,
      30,    2,  229,    2, 0x09 /* Protected */,
      31,    2,  234,    2, 0x09 /* Protected */,
      32,    2,  239,    2, 0x09 /* Protected */,
      33,    2,  244,    2, 0x09 /* Protected */,
      34,    0,  249,    2, 0x09 /* Protected */,
      35,    0,  250,    2, 0x09 /* Protected */,
      36,    2,  251,    2, 0x09 /* Protected */,
      38,    2,  256,    2, 0x09 /* Protected */,
      39,    2,  261,    2, 0x09 /* Protected */,
      40,    0,  266,    2, 0x09 /* Protected */,
      41,    0,  267,    2, 0x09 /* Protected */,

 // signals: parameters
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4, 0x80000000 | 6, QMetaType::Bool,    3,    5,    7,    8,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4, 0x80000000 | 6, 0x80000000 | 10,    3,    5,    7,   11,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4,    3,    5,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4,    3,    5,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4,    3,    5,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4,    3,    5,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 19,   20,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4, 0x80000000 | 6, QMetaType::Bool,    3,    5,    7,    8,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   25,   26,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4, 0x80000000 | 6, QMetaType::Bool,    3,    5,    7,   28,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4, 0x80000000 | 6, 0x80000000 | 10,    3,    5,    7,   11,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4,    3,    5,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4,    3,    5,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4,    3,    5,
    QMetaType::Void, QMetaType::UInt, 0x80000000 | 4,    3,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UInt, QMetaType::Bool,    3,   37,
    QMetaType::Void, QMetaType::UInt, QMetaType::Bool,    3,   37,
    QMetaType::Void, QMetaType::UInt, QMetaType::Bool,    3,   37,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->uiDeviceInserted((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2])),(*reinterpret_cast< const std::vector<usbguard::USBInterfaceType>(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 1: _t->uiDevicePresent((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2])),(*reinterpret_cast< const std::vector<usbguard::USBInterfaceType>(*)>(_a[3])),(*reinterpret_cast< usbguard::Rule::Target(*)>(_a[4]))); break;
        case 2: _t->uiDeviceRemoved((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2]))); break;
        case 3: _t->uiDeviceAllowed((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2]))); break;
        case 4: _t->uiDeviceBlocked((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2]))); break;
        case 5: _t->uiDeviceRejected((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2]))); break;
        case 6: _t->uiConnected(); break;
        case 7: _t->uiDisconnected(); break;
        case 8: _t->switchVisibilityState((*reinterpret_cast< QSystemTrayIcon::ActivationReason(*)>(_a[1]))); break;
        case 9: _t->flashStep(); break;
        case 10: _t->ipcTryConnect(); break;
        case 11: _t->showDeviceDialog((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2])),(*reinterpret_cast< const std::vector<usbguard::USBInterfaceType>(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 12: _t->showMessage((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 13: _t->showMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->notifyInserted((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2])),(*reinterpret_cast< const std::vector<usbguard::USBInterfaceType>(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 15: _t->notifyPresent((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2])),(*reinterpret_cast< const std::vector<usbguard::USBInterfaceType>(*)>(_a[3])),(*reinterpret_cast< usbguard::Rule::Target(*)>(_a[4]))); break;
        case 16: _t->notifyRemoved((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2]))); break;
        case 17: _t->notifyAllowed((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2]))); break;
        case 18: _t->notifyBlocked((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2]))); break;
        case 19: _t->notifyRejected((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< const std::map<std::string,std::string>(*)>(_a[2]))); break;
        case 20: _t->notifyIPCConnected(); break;
        case 21: _t->notifyIPCDisconnected(); break;
        case 22: _t->allowDevice((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 23: _t->blockDevice((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 24: _t->rejectDevice((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 25: _t->handleIPCConnect(); break;
        case 26: _t->handleIPCDisconnect(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MainWindow::*_t)(quint32 , const std::map<std::string,std::string> & , const std::vector<usbguard::USBInterfaceType> & , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::uiDeviceInserted)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(quint32 , const std::map<std::string,std::string> & , const std::vector<usbguard::USBInterfaceType> & , usbguard::Rule::Target );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::uiDevicePresent)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(quint32 , const std::map<std::string,std::string> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::uiDeviceRemoved)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(quint32 , const std::map<std::string,std::string> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::uiDeviceAllowed)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(quint32 , const std::map<std::string,std::string> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::uiDeviceBlocked)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)(quint32 , const std::map<std::string,std::string> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::uiDeviceRejected)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::uiConnected)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::uiDisconnected)) {
                *result = 7;
                return;
            }
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    if (!strcmp(_clname, "usbguard::IPCClient"))
        return static_cast< usbguard::IPCClient*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 27;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::uiDeviceInserted(quint32 _t1, const std::map<std::string,std::string> & _t2, const std::vector<usbguard::USBInterfaceType> & _t3, bool _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::uiDevicePresent(quint32 _t1, const std::map<std::string,std::string> & _t2, const std::vector<usbguard::USBInterfaceType> & _t3, usbguard::Rule::Target _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MainWindow::uiDeviceRemoved(quint32 _t1, const std::map<std::string,std::string> & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MainWindow::uiDeviceAllowed(quint32 _t1, const std::map<std::string,std::string> & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void MainWindow::uiDeviceBlocked(quint32 _t1, const std::map<std::string,std::string> & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MainWindow::uiDeviceRejected(quint32 _t1, const std::map<std::string,std::string> & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void MainWindow::uiConnected()
{
    QMetaObject::activate(this, &staticMetaObject, 6, Q_NULLPTR);
}

// SIGNAL 7
void MainWindow::uiDisconnected()
{
    QMetaObject::activate(this, &staticMetaObject, 7, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
